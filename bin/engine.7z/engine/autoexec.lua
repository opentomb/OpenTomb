-- LUA autoexec config file
-- CVAR's section. here you can create and delete CVAR's

if(cvars == nil) then
    cvars = {};
end;

-- CVAR's section. here you can create and delete CVAR's
cvars.show_fps = 1;
cvars.free_look_speed = 2500;

-- AUTOEXEC LINES
setLanguage("english");

setGravity(0, 0, -5700.0);
mlook(1);
freelook(0);
cam_distance(1024.0);
setCameraViewDistance(32768);
noclip(0);
--playVideo(base_path .. "data/tr1/fmv/CORE.RPL");
loadMap(base_path .. "data/TRIGGERS.PHD", 1, 0);
--setgamef(1, 8);
--dofile(base_path .. "save/qsave.lua");
