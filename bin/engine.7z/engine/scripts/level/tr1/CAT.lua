-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER UB, CAT

print("Level script loaded (CAT.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
