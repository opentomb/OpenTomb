-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER UB, EGYPT

print("Level script loaded (EGYPT.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
