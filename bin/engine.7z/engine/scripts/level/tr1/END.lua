-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER UB, END

print("Level script loaded (END.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
