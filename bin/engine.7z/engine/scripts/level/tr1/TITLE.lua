-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER, TITLE

print("Level script loaded (TITLE.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
