-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER 2, TITLE.TR2

print("Level script loaded (TITLE.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
