-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER 3 LA, TRTLA.TR2

print("Level script loaded (TRTLA.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
