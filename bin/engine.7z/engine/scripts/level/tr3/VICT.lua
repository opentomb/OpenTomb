-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER 3, VICT.TR2

print("Level script loaded (VICT.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
