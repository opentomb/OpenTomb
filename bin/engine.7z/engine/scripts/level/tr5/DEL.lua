-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER 5, DEL

print("Level script loaded (DEL.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
