-- OPENTOMB LEVEL SCRIPT
-- FOR TOMB RAIDER 5, TITLE

print("Level script loaded (TITLE.lua)");

level_PostLoad = function()

end;

level_PreLoad = function()
    -- STATIC COLLISION FLAGS ------------------------------------------------------
    --------------------------------------------------------------------------------
end;
